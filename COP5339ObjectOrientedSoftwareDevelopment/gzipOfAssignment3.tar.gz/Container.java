import java.util.Vector;

public class Container {

  private final String id;

  private final Integer size;

  private Integer weight;

  private Boolean fragileContents;

    public Ship Responsible For;
    public Vector  myShipStay;
    public Location stored At;

  public Container(String ContainerId) {
  }

}