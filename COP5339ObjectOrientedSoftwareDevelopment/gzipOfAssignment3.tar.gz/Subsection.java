import java.util.Vector;

public class Subsection extends Section {

  public Location location;

    public Location myLocation;
    /**
   * 
   * @element-type Section
   */
  public Vector  contains;

  public Subsection() {
  }

}