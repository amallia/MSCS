import java.util.Vector;

/*
 * getInstance()
 */
public class Port {

  private final Port thePort;

  private final Integer location;

    public Vector  loadUnload;
    /**
   * 
   * @element-type Operator
   */
  public Vector  myOperator;
    /**
   * 
   * @element-type Crane
   */
  public Vector  myCrane;
    /**
   * 
   * @element-type Warehouse
   */
  public Vector  myWarehouse;

  public void getInstance() {
  }

  public Port() {
  }

}