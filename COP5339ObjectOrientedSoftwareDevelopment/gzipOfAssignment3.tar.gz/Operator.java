import java.util.Vector;

public class Operator {

  public Integer id;

  public String name;

    /**
   * 
   * @element-type Crane
   */
  public Vector  qualifiedFor;
    public Vector  myPort;
    /**
   * 
   * @element-type CraneView
   */
  public Vector  Qualified for;

  public Operator() {
  }

}