import java.util.Vector;

public class CraneController {

  public Crane crane;

    public Vector  myCraneView;
    public Vector  myCrane;

  public CraneController() {
  }

}