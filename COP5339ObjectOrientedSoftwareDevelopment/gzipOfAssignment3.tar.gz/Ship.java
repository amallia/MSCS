import java.util.Vector;

public class Ship {

  private final String name;

  private final String country;

  private Location location;

    public Vector  stayAt;
    /**
   * 
   * @element-type Container
   */
  public Vector  Responsible For;

  public Ship() {
  }

}