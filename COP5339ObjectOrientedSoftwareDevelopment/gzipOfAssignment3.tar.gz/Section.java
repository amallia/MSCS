public class Section extends Warehouse {

  private Location location;

  public java.util.Vector subsections;

    public Subsection contains;

  public Section() {
  }

}