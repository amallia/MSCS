import java.util.Vector;

public class Warehouse {

  private String id;

  private Location location;

    public Vector  myPort;

  public Warehouse() {
  }

}