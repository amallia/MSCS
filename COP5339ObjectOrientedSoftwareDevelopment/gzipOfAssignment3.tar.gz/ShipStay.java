import java.util.Vector;

public class ShipStay {

  private UnlimitedInteger date;

    public Vector  loadUnload;
    public Vector  stayAt;
    /**
   * 
   * @element-type Container
   */
  public Vector  myContainer;

  public ShipStay() {
  }

}