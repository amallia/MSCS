import java.util.Vector;

public class Location extends Warehouse {

  private final Integer coordinates;

    public Container stored At;
    public Vector  mySubsection;

  public Location(Integer gpsCoordinates) {
  }

}