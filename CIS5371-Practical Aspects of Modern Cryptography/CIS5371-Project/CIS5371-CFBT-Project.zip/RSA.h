/*
 * RSA.h
 *
 *  Created on: Nov 28, 2018
 *      Author: Christopher Foley / Bijayita Thapa
 */
#include <string>
#include <cstring>
#include <ElGamal.h>					// use some utility functions
#include "cryptopp/integer.h"
#ifndef RSA_H_
#define RSA_H_
//enum state {FIRST, ENCRYPTION, DECRYPTION};

class RSA
{
public:
	RSA(int bit_length);
	RSA(int bit_length, CryptoPP::Integer modulus=0, CryptoPP::Integer exponent=0, CryptoPP::Integer decrypt_key=0); // encrypt/decrypt
	~RSA();
	bool get_public_key(CryptoPP::Integer *modulus, CryptoPP::Integer *exponent);
	bool get_private_key(CryptoPP::Integer *private_key);
	std::string encrypt(CryptoPP::Integer modulus, CryptoPP::Integer exponent, std::string );
	std::string decrypt(std::string );
	CryptoPP::Integer hexStringToInteger(std::string inString); // utility functions
	std::string integerToHexString(CryptoPP::Integer inInt);


private:

    int 			  bit_length=0;
	CryptoPP::Integer modulus;
	CryptoPP::Integer encryption_exponent;
	CryptoPP::Integer decryption_exponent;
	void _set_RSA(int bit_length,						// key length in bits
			           CryptoPP::Integer modulus,			// modulus
					   CryptoPP::Integer exponent, 			// encryption exponent
					   CryptoPP::Integer decrypt_key=0)	;     /* decryption exponent key */

};

#endif /* RSA_H_ */
