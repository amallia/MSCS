/*
 * AES.cpp
 *
 *  Created on: Nov 26, 2018
 *      Author: chris
 */
#include <assert.h>
#include "AES.h"
#include "AES_TABLES.h"
union pacific {
   uint32_t w32;
   uint8_t b8[4];
} ;

static unsigned int endian;
static const CryptoPP::Integer CZERO((long)0);
CryptoPP::Integer AES::hexStringToInteger(std::string inString)
{
	CryptoPP::Integer x = CZERO;
	for (unsigned int i = 0; i < inString.length(); i++)
	{
		int  n = char(inString[i]);
		if (n >= '0' && n <= '9')
			n = n - '0';
		else
			n = (n < 'a') ? n - 'A' +10 : n - 'a'+10;
		if (inString[i] != 'h')
		{
			x *=0x10;
			n &= 0x0f;
			x |= n;
		}
	}
	return x;

}
std::string AES::integerToHexString(CryptoPP::Integer inInt)
{
	size_t intLen = inInt.MinEncodedSize();
	std::string s;

	s.resize(intLen);
	inInt.Encode((CryptoPP::byte *)s.data(), s.size(), CryptoPP::Integer::UNSIGNED);

	return s;
}

void AES::key_expansion()
{
	uint32_t x[4];
	CryptoPP::Integer lkey = key;
	for (int i = 3; i >= 0; i--)
	{
		x[i] = lkey % 0x100000000;
		lkey /= 0x100000000;
	}
	for (int r=0; r< 4; r++)
	{
		pacific y;
		y.w32 = x[r];
		for (int c=0; c< 4; c++)
		{
			state[c][r] = y.b8[endian-c];
		};
	}
	// store key 0
	for (int r=0; r< 4; r++)
	{
		pacific y;
		for (int c=0; c< 4; c++)
		{
			y.b8[endian-c] = state[r][c];
		};
		key_rounds[0][r] = y.w32;
	}

									// now the remainder of rounds
	for (unsigned int i = 1;i < numRounds; i++)
	{
		pacific x;
		uint8_t swap;
		x.w32 = key_rounds[i-1][3];	// first that g function
		swap = x.b8[endian-0];
		x.b8[endian-0] = x.b8[endian-1];
		x.b8[endian-1] = x.b8[endian-2];
		x.b8[endian-2] = x.b8[endian-3];
		x.b8[endian-3] = swap;

		for (int j=0; j < 4; j++)	// now use sbox to make code readable
		{
			x.b8[endian-j] = sbox[x.b8[endian-j]];
		}
		x.b8[endian-0] = x.b8[endian-0] ^ rc[i];			// r with row coefficient

		key_rounds[i][0] = key_rounds[i-1][0] ^ x.w32;
		key_rounds[i][1] = key_rounds[i-1][1] ^ key_rounds[i][0];
		key_rounds[i][2] = key_rounds[i-1][2] ^ key_rounds[i][1];
		key_rounds[i][3] = key_rounds[i-1][3] ^ key_rounds[i][2];

	}
}
void AES::_initialize_aes()
{	// determine endianness of system for overlays
	unsigned int i = 1;
    char *c = (char*)&i;
    if (*c)
    	endian = 3;
    else
    	endian = 0;

	numRounds = (key_length/32) + 6;
    memset( key_array, 0x00, sizeof(uint8_t)*4*(key_length/32) );		// use key_length for future growth (now its fixed as 128 bits)
	memset( iv_array, 0x00, sizeof(uint8_t)*4*(key_length/32) );
	memset( key_rounds, 0x00, numRounds*sizeof(uint8_t)*4*(key_length/32) );  //max 12 rounds?
    memset(state, 0x00, 16);
#ifdef AES_DEBUG
    std::cout << "_initialize_aes::NumRounds:" << numRounds << std::endl;
#endif /* AES_DEBUG */
	key_expansion();													// set keys for 10 rounds
}
AES::AES()
{
	key_length = 128;
	key = 0;
	iv = 0.;
	_initialize_aes();
	// TODO Auto-generated constructor stub

}
AES::AES(unsigned int keylength, CryptoPP::Integer key) {
	assert (keylength == 128);												// for now only 128 bits allowed
	key_length = keylength; 											// convert from bytes to bits;
	this->key = key;
	this->iv = 0;
	_initialize_aes();
}

AES::~AES() {

}

void AES::add_keys(unsigned int round)
{
	pacific keyset;
	for (int r=0;r < 4;r++)
	{
		keyset.w32 = key_rounds[round][r];
		for (int c=0; c< 4; c++) state[r][c] ^= keyset.b8[endian-c];
	}
#ifdef AES_DEBUG
    std::cout << "add_keys::round:" << round << std::endl;
#endif /* AES_DEBUG */
}

void AES::substitute_bytes()
{							// back to the stable
#ifdef AES_DEBUG
    std::cout << "substitute_bytes" << std::endl;
#endif /* AES_DEBUG */
	for (int r=0;r < 4;r++)
		for (int c=0; c< 4; c++) state[r][c] = sbox[state[r][c]];
}

void AES::inv_substitute_bytes()
{							// back to the stable
#ifdef AES_DEBUG
    std::cout << "inv_substitute_bytes" << std::endl;
#endif /* AES_DEBUG */
	for (int r=0;r < 4;r++)
		for (int c=0; c< 4; c++) state[r][c] = rsbox[state[r][c]];
}

void AES::shift_row()
{
	for (unsigned int r=0;r < 4;r++)
	{
		pacific swap;
		swap.b8[endian-0] = state[r][0];
		swap.b8[endian-1] = state[r][1];
		swap.b8[endian-2] = state[r][2];
		swap.b8[endian-3] = state[r][3];
		swap.w32 = rol32(swap.w32, r*8);
		state[r][0] = swap.b8[endian-0];
		state[r][1] = swap.b8[endian-1];
		state[r][2] = swap.b8[endian-2];
		state[r][3] = swap.b8[endian-3];
	}
#ifdef AES_DEBUG
    std::cout << "shift_row" << std::endl;
#endif /* AES_DEBUG */

}
void AES::inv_shift_row()
{
	for (unsigned int r=0;r < 4;r++)
	{
		pacific swap;
		swap.b8[endian-0] = state[r][0];
		swap.b8[endian-1] = state[r][1];
		swap.b8[endian-2] = state[r][2];
		swap.b8[endian-3] = state[r][3];
		swap.w32 = ror32(swap.w32, r*8);
		state[r][0] = swap.b8[endian-0];
		state[r][1] = swap.b8[endian-1];
		state[r][2] = swap.b8[endian-2];
		state[r][3] = swap.b8[endian-3];
	}
#ifdef AES_DEBUG
    std::cout << "inv_shift_row" << std::endl;
#endif /* AES_DEBUG */

}
// xtime, multiply, mix_col and unmix_col were taken directly from AES_Decrypt
/* see header below
******************************************************************
**       Advanced Encryption Standard implementation in C.      **
**       By Niyaz PK                                            **
**       E-mail: niyazlife@gmail.com                            **
**       Downloaded from Website: www.hoozi.com                 **
******************************************************************/

// xtime is a macro that finds the product of {02} and the argument to xtime modulo {1b}
#define xtime(x)   ((x<<1) ^ (((x>>7) & 1) * 0x1b))
// Multiplty is a macro used to multiply numbers in the field GF(2^8)
#define Multiply(x,y) (((y & 1) * x) ^ ((y>>1 & 1) * xtime(x)) ^ ((y>>2 & 1) * xtime(xtime(x))) ^ ((y>>3 & 1) * xtime(xtime(xtime(x)))) ^ ((y>>4 & 1) * xtime(xtime(xtime(xtime(x))))))

void AES::mix_col()
{
	int i;
	unsigned char Tmp,Tm,t;
	for(i=0;i<4;i++)
	{
		t=state[0][i];
		Tmp = state[0][i] ^ state[1][i] ^ state[2][i] ^ state[3][i] ;
		Tm = state[0][i] ^ state[1][i] ; Tm = xtime(Tm); state[0][i] ^= Tm ^ Tmp ;
		Tm = state[1][i] ^ state[2][i] ; Tm = xtime(Tm); state[1][i] ^= Tm ^ Tmp ;
		Tm = state[2][i] ^ state[3][i] ; Tm = xtime(Tm); state[2][i] ^= Tm ^ Tmp ;
		Tm = state[3][i] ^ t ; Tm = xtime(Tm); state[3][i] ^= Tm ^ Tmp ;
	}
#ifdef AES_DEBUG
    std::cout << "mix_column layer" << std::endl;
#endif /* AES_DEBUG */
}

void AES::unmix_col()
{
	int i;
	unsigned char a,b,c,d;
	for(i=0;i<4;i++)
	{

		a = state[0][i];
		b = state[1][i];
		c = state[2][i];
		d = state[3][i];


		state[0][i] = Multiply(a, 0x0e) ^ Multiply(b, 0x0b) ^ Multiply(c, 0x0d) ^ Multiply(d, 0x09);
		state[1][i] = Multiply(a, 0x09) ^ Multiply(b, 0x0e) ^ Multiply(c, 0x0b) ^ Multiply(d, 0x0d);
		state[2][i] = Multiply(a, 0x0d) ^ Multiply(b, 0x09) ^ Multiply(c, 0x0e) ^ Multiply(d, 0x0b);
		state[3][i] = Multiply(a, 0x0b) ^ Multiply(b, 0x0d) ^ Multiply(c, 0x09) ^ Multiply(d, 0x0e);
	}
#ifdef AES_DEBUG
    std::cout << "unmix_column layer" << std::endl;
#endif /* AES_DEBUG */
}

std::string AES::encrypt(std::string plaintext)
{
	std::string ciphertext="";
	unsigned int pi=0;
#ifdef AES_DEBUG
	std::cout << "AES::encrypt:(" << plaintext.length() << ") bytes" << std::endl;
#endif /* AES_DEBUG */
	while (pi < plaintext.length())
	{
		for (int c=0;c < 4; c++)		// plaintext into state array and pad if needed
		{
			for (int r=0; r < 4; r++)
			{
				state[r][c] = (pi < plaintext.length())? plaintext[pi++] : 0;
			}
		}
		// key addition layer (key[0])
		add_keys(0);
		for (unsigned int round = 1; round < numRounds; round++)
		{
			// byte substitution layer
			substitute_bytes();
			// shift row layer
			shift_row();
			// mix column layer
			mix_col();
			// key addition layer
			add_keys(round);
		}
		// last round
		substitute_bytes();
		shift_row();
		add_keys(numRounds);

		// copy to Integer then convert to string;

		CryptoPP::Integer cipher((long)0);
		pacific x;
		x.w32 = 0;
		for (int r=0; r < 4; r++)
		{
			for (int c=0; c< 4; c++)
			{
				x.b8[endian-c] = state[c][r];
			}
			cipher *=                0x0100000000;		// shift 32 bits
			unsigned int j = x.w32 & 0x00ffffffff;		// only keep lower 32 bits
			cipher += j;
		}
		ciphertext += integerToHexString(cipher);
	}
	return ciphertext;
}

std::string AES::decrypt(std::string ciphertext)
{
	std::string plaintext="";
	unsigned int pi=0;
#ifdef AES_DEBUG
	std::cout << "AES::decrypt:(" << ciphertext.length() << ") bytes" << std::endl;
#endif /* AES_DEBUG */
	while (pi < ciphertext.length())
	{
		for (int c=0;c < 4; c++)		// plaintext into state array and pad if needed
		{
			for (int r=0; r < 4; r++)
			{
				state[r][c] = (pi < ciphertext.length())? ciphertext[pi++] : 0;
			}
		}
		add_keys(numRounds);
		inv_shift_row();
		inv_substitute_bytes();
		for (unsigned int rounds=numRounds-1; rounds > 0; rounds--)
		{
			add_keys(rounds);
			unmix_col();
			inv_shift_row();
			inv_substitute_bytes();
		}
		add_keys(0);
		// copy to Integer then convert to string;

		CryptoPP::Integer cipher((long)0);
		for (int r=0; r < 4; r++)
		{
			pacific x;
			x.w32 = 0;
			for (int c=0; c< 4; c++)
			{
				x.b8[endian-c] = state[c][r];
			}
			cipher *=                0x0100000000;		// shift 32 bits
			unsigned int j = x.w32 & 0x00ffffffff;		// only keep lower 32 bits
			cipher += j;

		}
		plaintext += integerToHexString(cipher);
	}

	return plaintext;
}

