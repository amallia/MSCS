/*
 * RSA_TEST.cpp
 *
 *  Created on: Nov 28, 2018
 *      Author: chris
 */
#include <iostream>
#include <iomanip>
#include <string>
#include <cstring>
#include "cryptopp/integer.h"
#include "RSA.h"
using namespace std;
int mainr(int argc, char *argv[])
{
	RSA a(128, 6012707, 3674911, 422191);
	RSA b(128, 6012707, 3674911, 422191);
	CryptoPP::Integer m, x = 3674911.;
	m = 5234673;	// message
	x *= 422191;
	x %= 6012707;
	if (x.IsUnit()) std::cout << "Viagra exponents ok\n";
	std::string plaintext;
	plaintext = a.integerToHexString(m);
	std::string ciphertext = "";
	ciphertext = a.encrypt(6012707, 3674911, plaintext);
	if (plaintext==b.decrypt(ciphertext)) { std::cout << "Match\n";};
	x = a.hexStringToInteger(ciphertext);
	std::cout << m << std::endl << x << std::endl << a.encrypt(6012707., 3674911., "\x4F\xDF\xF1") << std::endl;

}


