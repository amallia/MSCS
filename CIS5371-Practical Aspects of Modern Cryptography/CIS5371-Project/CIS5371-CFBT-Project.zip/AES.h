/*
 * AES.h
 *
 *  Created on: Nov 26, 2018
 *      Author: chris
 */
#include "cryptopp/integer.h"
#include "cryptopp/osrng.h"
#include "cryptopp/hrtimer.h"
#include "cryptopp/algparam.h"
#include "cryptopp/nbtheory.h"
#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
#include <exception>
#include <malloc.h>
#include <assert.h>

#ifndef AES_H_
#define AES_H_
//#define AES_DEBUG

static uint32_t rol32(uint32_t x, int n)
{
	assert(n<32);
	return (x<<n | x >> (32-n));
}

static uint32_t ror32(uint32_t x, int n)
{
	assert(n<32);
	return(x>>n | x << (32-n));
}

class AES {
public:
	AES();
	AES(unsigned int keylength, CryptoPP::Integer key);
	std::string encrypt(std::string plaintext);
	std::string decrypt(std::string siphertext);
	virtual ~AES();
	CryptoPP::Integer hexStringToInteger(std::string);
	std::string       integerToHexString(CryptoPP::Integer);


private:
	void _initialize_aes();
	void key_expansion();
	void add_keys(unsigned int);
	void substitute_bytes();
	void inv_substitute_bytes();
	void shift_row();
	void inv_shift_row();
	void mix_col();
	void unmix_col();
	CryptoPP::Integer key;
	CryptoPP::Integer iv;
	unsigned int key_length, numRounds;
	uint8_t key_array[4][4], iv_array[4][4];
	uint32_t key_rounds[14][4];
	uint8_t state[4][4];		// state table for encryption and decryption
};

#endif /* AES_H_ */
