/*
 * RSA.cpp
 *
 *  Created on: Nov 28, 2018
 *      Author: Christopher Foley / Bijayita Thapa
 */
#include "cryptopp/integer.h"
#include "cryptopp/osrng.h"
#include "cryptopp/hrtimer.h"
#include "cryptopp/algparam.h"
#include "cryptopp/nbtheory.h"
#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
#include <exception>
#include <assert.h>
#include <ElGamal.h>
#include "RSA.h"
static const CryptoPP::Integer CZERO((long)0);

CryptoPP::Integer RSA::hexStringToInteger(std::string inString)
{
	CryptoPP::Integer x = CZERO;
	for (unsigned int i = 0; i < inString.length(); i++)
	{
		int  n = char(inString[i]);
		if (n >= '0' && n <= '9')
			n = n - '0';
		else
			n = (n < 'a') ? n - 'A' +10 : n - 'a'+10;
		if (inString[i] != 'h')
		{
			x *=0x10;
			n &= 0x0f;
			x |= n;
		}
	}
	return x;

}
std::string RSA::integerToHexString(CryptoPP::Integer inInt)
{
	size_t intLen = inInt.MinEncodedSize();
	std::string s;

	s.resize(intLen);
	inInt.Encode((CryptoPP::byte *)s.data(), s.size(), CryptoPP::Integer::UNSIGNED);

	return s;
}


bool RSA::get_public_key(CryptoPP::Integer *modulus, CryptoPP::Integer *encryption_exponent)
{
	if (!this->modulus.IsZero())
	{
		*modulus = this->modulus;
		*encryption_exponent = this->encryption_exponent;
	}
	return !this->modulus.IsZero();
}

bool RSA::get_private_key(CryptoPP::Integer *decryption_exponent)
{
	*decryption_exponent = this->decryption_exponent;
	return !this->decryption_exponent.IsZero();
}

void RSA::_set_RSA(int bit_length,						// key length in bits
		           CryptoPP::Integer modulus,			// modulus
				   CryptoPP::Integer exponent, 			// encryption exponent
				   CryptoPP::Integer decrypt_key)	     /* decryption exponent key */
{
	if ((bit_length & (bit_length-1)) != 0) throw "bit length not power of 2";
	this->bit_length = bit_length;
	this->modulus = modulus;
	encryption_exponent = exponent;
	decryption_exponent = decrypt_key;
	if (this->modulus.IsZero())
	{
		CryptoPP::Integer p, q, universal_exp;
		CryptoPP::AutoSeededRandomPool prng;
		CryptoPP::AlgorithmParameters params = CryptoPP::MakeParameters("BitLength", bit_length, false)
													("RandomNumberType", CryptoPP::Integer::ANY, false);

		CryptoPP::PrimeAndGenerator png;
    //  new parameters
    	png.Generate(1, prng, bit_length, bit_length-16);
    	p = png.Prime();
    	q = png.SubPrime();
    	this->modulus = p * q;
    	universal_exp = CryptoPP::LCM(p, q);
   	    encryption_exponent = CryptoPP::Integer(prng, (CryptoPP::Integer)1, universal_exp);
    	while (!CryptoPP::RelativelyPrime(encryption_exponent, universal_exp))
    	{
       	    encryption_exponent = CryptoPP::Integer(prng, (CryptoPP::Integer)1, universal_exp);
    	}

/*
 *			find multiplicative inverse of encryption exponent mod universal exponent
 *
 */
    	decryption_exponent = encryption_exponent.InverseMod(this->modulus);
    }
}
RSA::RSA(int key_length)
{
	CryptoPP::Integer CZERO = 0;
	RSA::_set_RSA(key_length, CZERO, CZERO, CZERO);
}

RSA::RSA(int bit_length,						// key length in bits
		 CryptoPP::Integer modulus,			// modulus
		 CryptoPP::Integer exponent, 			// encryption exponent
		 CryptoPP::Integer decrypt_key)	     /* decryption exponent key */
{
	_set_RSA(bit_length, modulus, exponent, decrypt_key);
}
RSA::~RSA()
{
}

std::string RSA::encrypt(CryptoPP::Integer modulus, CryptoPP::Integer encryption_exponent, std::string plaintext)
{
	CryptoPP::Integer m,x;
	unsigned int pi=0;				// cipher index and plain index
	std::string temp, ciphertext=plaintext;
    ciphertext = "";
	{
		std::stringstream xs;  // generator stream, encrypted stream

		m = 0;
		for (unsigned int i=0; i < modulus.MinEncodedSize();i++)				// use bytes to encode prime - 1 (zero relative)
		{
			if (pi < plaintext.length())
			{
				m *= 0x100;
				unsigned int j = (int)plaintext[pi++] & 0x00ff;		// move character otherwise pad with zero due to shift
				m += j;
			}
		}
//		x = A_exp_B_mod_C(m, encryption_exponent, modulus);  use CryptoPP version since its easier to link to
		x = a_exp_b_mod_c(m, encryption_exponent, modulus);

#ifdef _RSA_DEBUG_
		std::cout << "m (hex):" << std::hex << m << std::endl;
		std::cout << "Cipher??" << std::hex << x << std::endl;
#endif
		xs << std::hex << x;
		xs >> temp;
	    ciphertext = ciphertext + temp;
#ifdef _RSA_DEBUG_
//		std::cout << "Temp:" << temp << std::endl;
//		std::cout << "rvalue:" << ciphertext << std::endl;
#endif
	}

	return ciphertext;
}

std::string RSA::decrypt(std::string ciphertext)
{
	std::string plaintext, temp;
	std::stringstream ss, ss2;
	CryptoPP::Integer m,x,d,g,q;

	if (decryption_exponent.IsZero())
	{
		throw "Key not set.";
	}
	plaintext = "";
#ifdef _RSA_DEBUG_
//	std::cout  << "decrypt g(string):" << temp << std::endl;
//	std::cout  << "decrypt y(string):" << ciphertext << std::endl;
#endif
	x = hexStringToInteger(ciphertext);
	m = a_exp_b_mod_c(x, decryption_exponent, modulus);
#ifdef _RSA_DEBUG_
	std::cout << "decrypt x:(Integer)" << std::hex << x << std::endl;
	std::cout << "m:>>" << std::hex << m << "<<:" << std::endl;
#endif
	plaintext += integerToHexString(m);

	return plaintext;
}
