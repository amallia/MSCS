#include <iostream>
#include <iomanip>

#include "modes.h"
#include "aes.h"
#include "RSA.h"
#include "AES.h"
#include "filters.h"
static const CryptoPP::Integer CZERO((int)0);
int main3(int argc, char *argv[])
{
	RSA a(128, 6012707, 3674911, 422191);
	RSA b(128, 6012707, 3674911, 422191);
	CryptoPP::Integer m, x = 3674911.;
	m = 5234673;	// message
	x *= 422191;
	x %= 6012707;
	if (x.IsUnit()) std::cout << "Viagra exponents ok\n";
	std::string plaintext;
	plaintext = a.integerToHexString(m);
	std::string ciphertext = "";
	ciphertext = a.encrypt(6012707, 3674911, plaintext);
	if (plaintext==b.decrypt(ciphertext)) { std::cout << "Match\n";};
	x = a.hexStringToInteger(ciphertext);
	std::cout << m << std::endl << x << std::endl << a.encrypt(6012707., 3674911., "\x4F\xDF\xF1") << std::endl;
	return 0;
}

int main1(int argc, char* argv[]) {
	CryptoPP::Integer modulus, encryptexp, decryptexp, integerKey;
    //Key and IV setup
    //AES encryption uses a secret key of a variable length (128-bit, 196-bit or 256-
    //bit). This key is secretly exchanged between two parties before communication
    //begins. DEFAULT_KEYLENGTH= 16 bytes
	RSA k(128, CZERO, CZERO, CZERO);
	k.get_public_key(&modulus, &encryptexp);
	k.get_private_key(&decryptexp);
	std::string plainkey = "This is a key?";
	std::string key = k.encrypt(modulus, encryptexp, plainkey);
	integerKey = k.hexStringToInteger(key);
	std::cout << "Encrypted key: <" << plainkey << "> as " << std::hex << key << " (" << integerKey.MinEncodedSize() << ")\n"
			  << std::hex << integerKey << std::endl;
	//integerKey = CZERO;
	AES a(128, integerKey);

    //
    // String and Sink setup
    //
    std::string plaintext = "Now is the time for all good men to come to the aide...";
    //std::string plaintext = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    std::string ciphertext="";
    std::string decryptedtext="";

    //
    // Dump Plain Text
    //
    std::cout << "Plain Text (" << plaintext.size() << " bytes)" << std::endl;
    std::cout << plaintext;
    std::cout << std::endl << std::endl;

    //
    // Create Cipher Text
    //
    ciphertext = "";
    ciphertext = a.encrypt(plaintext);
    //
    // Dump Cipher Text
    //
    std::cout << "Cipher Text (0x" << ciphertext.size() << " bytes)" << std::endl;

    for( int i = 0; i < ciphertext.size(); i++ ) {

        std::cout << "0x" << std::hex << (0xFF & static_cast<uint8_t>(ciphertext[i])) << " ";
    }

    std::cout << std::endl << std::endl;

    //
    // Decrypt
    //
    decryptedtext = a.decrypt(ciphertext);
    //
    // Dump Decrypted Text
    //
    std::cout << "Decrypted Text: " << std::endl;
    std::cout << decryptedtext;
    std::cout << std::endl << std::endl;
    std::cout << "Decrypted Text (" << decryptedtext.size() << " bytes)" << std::endl;

    for( int i = 0; i < decryptedtext.size(); i++ ) {

        std::cout << "0x" << std::hex << (0xFF & static_cast<uint8_t>(decryptedtext[i])) << " ";
    }

    std::cout << std::endl;
    if (decryptedtext == plaintext )
    	{
    	std::cout << "Match"<< std::endl;
    	}
    else
    {
    	std::cout << "Match"<< std::endl;
    }


    return 0;
}
int main2(int argc, char* argv[]) {

    //Key and IV setup
    //AES encryption uses a secret key of a variable length (128-bit, 196-bit or 256-   
    //bit). This key is secretly exchanged between two parties before communication   
    //begins. DEFAULT_KEYLENGTH= 16 bytes
    uint8_t key[ CryptoPP::AES::DEFAULT_KEYLENGTH ], iv[ CryptoPP::AES::BLOCKSIZE ];
    memset( key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH );
    memset( iv, 0x00, CryptoPP::AES::BLOCKSIZE );

    //
    // String and Sink setup
    //
    std::string plaintext = "Now is the time for all good men to come to the aide...";
    std::string ciphertext;
    std::string decryptedtext;

    //
    // Dump Plain Text
    //
    std::cout << "Plain Text (" << plaintext.size() << " bytes)" << std::endl;
    std::cout << plaintext;
    std::cout << std::endl << std::endl;

    //
    // Create Cipher Text
    //
    CryptoPP::AES::Encryption aesEncryption(key, CryptoPP::AES::DEFAULT_KEYLENGTH);
    CryptoPP::CBC_Mode_ExternalCipher::Encryption cbcEncryption( aesEncryption, iv );

    CryptoPP::StreamTransformationFilter stfEncryptor(cbcEncryption, new CryptoPP::StringSink( ciphertext ) );
    stfEncryptor.Put( reinterpret_cast<const unsigned char*>( plaintext.c_str() ), plaintext.length() + 1 );
    stfEncryptor.MessageEnd();

    //
    // Dump Cipher Text
    //
    std::cout << "Cipher Text (" << ciphertext.size() << " bytes)" << std::endl;

    for( int i = 0; i < ciphertext.size(); i++ ) {

        std::cout << "0x" << std::hex << (0xFF & static_cast<uint8_t>(ciphertext[i])) << " ";
    }

    std::cout << std::endl << std::endl;

    //
    // Decrypt 
    //
    CryptoPP::AES::Decryption aesDecryption(key, CryptoPP::AES::DEFAULT_KEYLENGTH);
    CryptoPP::CBC_Mode_ExternalCipher::Decryption cbcDecryption( aesDecryption, iv );

    CryptoPP::StreamTransformationFilter stfDecryptor(cbcDecryption, new CryptoPP::StringSink( decryptedtext ) );
    stfDecryptor.Put( reinterpret_cast<const unsigned char*>( ciphertext.c_str() ), ciphertext.size() );
    stfDecryptor.MessageEnd();

    //
    // Dump Decrypted Text
    //
    std::cout << "Decrypted Text: " << std::endl;
    std::cout << decryptedtext;
    std::cout << std::endl << std::endl;

    return 0;
}
int test(int argc, char* argv[]) {
	std::cout << "Run the RSA test stuff\n";
	main3(argc, argv);
	std::cout << "Do it with CryptoPP and get:\n";
    main2(argc, argv);
	std::cout << "\nDo it with Our stuff and get:\n";
    main1(argc, argv);
    return 0;
}
